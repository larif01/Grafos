# algoritmo_coloracao.py
import time
from typing import List, Tuple
from leitor_arquivos import ler_arquivo

def is_valid_coloring(grafo, coloracao):
    for v in range(len(grafo.vertices)):
        for vizinho in grafo.retornar_vizinhos(v):
            if coloracao[v] == coloracao[vizinho]:
                return False
    return True

def gerar_todas_coloracoes(n, k):
    if n == 0:
        yield []
        return
    for cor in range(k):
        for sub in gerar_todas_coloracoes(n - 1, k):
            yield [cor] + sub

def forca_bruta_coloracao(grafo):
    n = len(grafo.vertices)
    for k in range(1, n + 1):
        for tentativa in gerar_todas_coloracoes(n, k):
            if is_valid_coloring(grafo, tentativa):
                return tentativa, k
    return [], n

def heuristica_welsh_powell(grafo):
    graus = [(v, len(grafo.retornar_vizinhos(v))) for v in range(len(grafo.vertices))]
    ordem = [v for v, _ in sorted(graus, key=lambda x: -x[1])]
    return colorir_por_ordem(grafo, ordem)

def heuristica_dsat(grafo):
    n = len(grafo.vertices)
    cor = [-1] * n
    dsat = [0] * n
    grau = [len(grafo.retornar_vizinhos(v)) for v in range(n)]

    for _ in range(n):
        nao_coloridos = [(dsat[v], grau[v], v) for v in range(n) if cor[v] == -1]
        _, _, u = max(nao_coloridos)
        usadas = set(cor[v] for v in grafo.retornar_vizinhos(u) if cor[v] != -1)
        for c in range(n):
            if c not in usadas:
                cor[u] = c
                break
        for v in grafo.retornar_vizinhos(u):
            if cor[v] == -1:
                vizinhos_cores = set(cor[w] for w in grafo.retornar_vizinhos(v) if cor[w] != -1)
                dsat[v] = len(vizinhos_cores)
    return cor, max(cor) + 1

def heuristica_simples(grafo):
    n = len(grafo.vertices)
    cor = [-1] * n
    for v in range(n):
        usadas = set(cor[u] for u in grafo.retornar_vizinhos(v) if cor[u] != -1)
        for c in range(n):
            if c not in usadas:
                cor[v] = c
                break
    return cor, max(cor) + 1

def colorir_por_ordem(grafo, ordem):
    n = len(grafo.vertices)
    cor = [-1] * n
    for v in ordem:
        usadas = set(cor[u] for u in grafo.retornar_vizinhos(v) if cor[u] != -1)
        for c in range(n):
            if c not in usadas:
                cor[v] = c
                break
    return cor, max(cor) + 1

def testar_coloracao(nome_arquivo):
    grafo = ler_arquivo(nome_arquivo, representacao="lista")

    if grafo is None:
        print(f"❌ Arquivo '{nome_arquivo}' não pôde ser carregado.")
        return

    print(f"\n--- Testando: {nome_arquivo} ---")
    print("Número de vértices:", len(grafo.vertices))

    for nome, func in [
        ("Força Bruta", forca_bruta_coloracao),
        ("Welsh-Powell", heuristica_welsh_powell),
        ("DSATUR", heuristica_dsat),
        ("Heurística Simples", heuristica_simples)
    ]:
        if nome == "Força Bruta" and len(grafo.vertices) > 10:
            print(f"{nome}: ignorado (grafo muito grande)")
            continue
        ini = time.time()
        coloracao, num_cores = func(grafo)
        fim = time.time()
        print(f"{nome}: {num_cores} cores em {fim - ini:.4f}s")
        if len(grafo.vertices) <= 10:
            print("Vértices e cores:", list(enumerate(coloracao)))

if __name__ == "__main__":
    arquivos_teste = [
        "espacoaereo.txt",
        "grafo_direcionado_Ponderado_Direcionado.txt",
        "grafo_grande_completo.txt",
        "grafo_ponderado_Ponderado_NDirecionado.txt",
        "grafo_simples_NPonderadoNDirecionado.txt"
    ]
    for nome in arquivos_teste:
        testar_coloracao(nome)
